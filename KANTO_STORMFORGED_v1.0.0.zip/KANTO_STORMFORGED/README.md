# KANTO: STORMFORGED

A custom Gen1Recomp cart built on **Pokémon Yellow**.

The concept is a storm-lit, rebuilt Kanto where the world is visually modernized,
wild Pokémon inhabit the overworld, Weather FX and WX variants reshape encounters,
and Ultron adds autonomous robot rivals living alongside the player.

## What the cart pins

1. Kanto Reforged 1.5.3
2. Weather FX 4.31.0
3. WX Pokémon / Weather Variants 1.0.0
4. Ultron 2.47.1
5. Wilds of Kanto 2.1.9
6. Mystery Gift 0.1.0
7. Dramaless Shape 2.0.3
8. Better Buildings 1.16.0
9. HGSS Visual Overhaul 1.0.2
10. Pokéball Colors 0.1.33
11. Modern PC UI 0.4.1

### Companion install: Running Shoes 1.1.2

The requested Running Shoes release is published in the multi-mod repository
`johnjohto/pokemon-mods` under the Git tag `jj_running_shoes-v1.1.2`.

Gen1Recomp's current custom-cart resolver only accepts GitHub release tags named
`v<semver>` or `<semver>`. Because of that upstream tag shape, Running Shoes
cannot currently be represented as a valid native cart pin.

This cart is therefore **OPEN**. After importing the `.g1rcart`, install:

`jj_running_shoes-v1.1.2.zip`

from:

`https://github.com/johnjohto/pokemon-mods/releases/tag/jj_running_shoes-v1.1.2`

That gives the requested 12-mod setup without placing a deliberately broken pin
inside the cart.

## Why Better Buildings is 1.16.0

The newest Better Buildings build is 1.19.0, but its release tag is `night`.
The latest release with a tag that the stock cart resolver can pin is v1.16.0.
That version already declares Dramaless Shape compatibility and contains the
major Kanto building overhaul.

## Recommended load order

The cart fixes this order:

1. Kanto Reforged
2. Weather FX
3. WX Pokémon
4. Ultron
5. Wilds of Kanto
6. Mystery Gift
7. Dramaless Shape
8. Better Buildings
9. HGSS Visual Overhaul
10. Pokéball Colors
11. Modern PC UI

Running Shoes is installed as the companion mod after the cart.

## Install

1. Open Gen1Recomp.
2. Import `kanto_stormforged-1.0.0.g1rcart`.
3. Let Gen1Recomp download and verify the pinned mods.
4. Import Running Shoes 1.1.2 separately.
5. Fully restart Gen1Recomp before beginning a new Yellow save.

The cart requires a Gen1Recomp engine compatible with `>=0.1.86 <1.0.0`.

## Notes

- The cart is open because Running Shoes cannot yet be represented by the current GitHub pin schema.
- Kanto Reforged is the foundational gameplay/content layer.
- Dramaless Shape is loaded before Better Buildings so its optional compatibility path is available.
- Modern PC UI is deliberately last, after the visual and overworld providers it can integrate with.
- Weather FX is explicitly designed to coexist with Kanto Reforged and voxel/3D mods.
- Ultron's GitHub release is 2.47.1, although its tagged `manifest.json` currently reports an older internal version. The cart pins the published 2.47.1 release asset and its SHA-256.

## Cart identity

- Title: KANTO: STORMFORGED
- ID: `kanto_stormforged`
- Version: 1.0.0
- Base: Yellow
- Shell: storm blue `#203746`
- Finish: holo
- Seal: open
- Allowed game speeds: 1x, 2x
